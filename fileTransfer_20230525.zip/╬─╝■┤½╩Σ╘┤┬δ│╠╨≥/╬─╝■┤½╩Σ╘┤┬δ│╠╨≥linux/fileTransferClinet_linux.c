#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <stdbool.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netdb.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <iconv.h>

#define DEFAULT_BUFLEN 8192

#define MAX_INTERFACES 16

void convertEncoding(const char* fromEncoding, const char* toEncoding, const char* src, char* dest, size_t destSize) {
    iconv_t cd = iconv_open(toEncoding, fromEncoding);
    if (cd == (iconv_t)-1) {
        perror("Failed to open iconv");
        exit(1);
    }

    size_t srcLen = strlen(src);
    size_t destLen = destSize - 1;  // Leave room for null terminator

    char* srcPtr = (char*)src;
    char* destPtr = dest;

    if (iconv(cd, &srcPtr, &srcLen, &destPtr, &destLen) == (size_t)-1) {
        perror("Failed to convert encoding");
        exit(1);
    }

    // Null terminate the destination buffer
    *destPtr = '\0';

    iconv_close(cd);
}

void replaceBackslashWithSlash(char* str) {
    if (str == NULL) {
        return;
    }

    int length = strlen(str);
    for (int i = 0; i < length; i++) {
        if (str[i] == '\\') {
            str[i] = '/';
        }
    }
}

int getLocalIP(char* ip) {
    int fd, interfaceCount, i;
    struct ifreq buf[MAX_INTERFACES];
    struct ifconf ifc;

    ifc.ifc_len = sizeof(buf);
    ifc.ifc_buf = (caddr_t)buf;

    if ((fd = socket(AF_INET, SOCK_DGRAM, 0)) < 0) {
        perror("socket");
        return -1;
    }

    if (ioctl(fd, SIOCGIFCONF, (char*)&ifc) < 0) {
        perror("ioctl(SIOCGIFCONF)");
        close(fd);
        return -1;
    }

    interfaceCount = ifc.ifc_len / sizeof(struct ifreq);
    for (i = 0; i < interfaceCount; i++) {
        struct ifreq* ifr = &buf[i];

        if (ioctl(fd, SIOCGIFFLAGS, (char*)ifr) < 0) {
            perror("ioctl(SIOCGIFFLAGS)");
            close(fd);
            return -1;
        }

        if (ifr->ifr_flags & IFF_LOOPBACK)
            continue;

        if (ioctl(fd, SIOCGIFADDR, (char*)ifr) < 0) {
            perror("ioctl(SIOCGIFADDR)");
            close(fd);
            return -1;
        }

        struct sockaddr_in* addr = (struct sockaddr_in*)&ifr->ifr_addr;
        strcpy(ip, inet_ntoa(addr->sin_addr));
        close(fd);
        return 0;
    }

    close(fd);
    return -1;
}

void error(const char* msg) {
    perror(msg);
    exit(1);
}

void receiveFile(int sockfd, const char* fileName) {
    int n;
    char buffer[DEFAULT_BUFLEN];
    long long fileSize;
    long long nowSize;

    convertEncoding("UTF-8", "GBK", fileName, buffer, DEFAULT_BUFLEN);
    send(sockfd, buffer, strlen(buffer), 0);
    n = recv(sockfd, buffer, DEFAULT_BUFLEN, 0);
    if (n <= 0) {
        printf("接收文件大小失败\n");
        return;
    }
    buffer[n] = '\0';
    fileSize = atoll(buffer);
    convertEncoding("UTF-8", "GBK", buffer, buffer, DEFAULT_BUFLEN);
    send(sockfd, buffer, strlen(buffer), 0);

    FILE* fp = fopen(fileName, "wb");
    if (fp == NULL) {
        error("创建文件失败");
    }

    float lastProgress = 0.0f;
    nowSize = 0;
    while (1) {
		// 计算进度百分比
		float progress;
		if (fileSize==0){
			progress = 100;
		}
		else{
			progress = (float)nowSize / fileSize * 100;
		}
        if (progress != lastProgress) {
            printf("\r");
            printf("已接收 %.2f%%", progress);
            fflush(stdout);
            lastProgress = progress;
        }
        if (nowSize >= fileSize) {
            printf("\n接收完成\n");
            break;
        }
        memset(buffer, 0, DEFAULT_BUFLEN);
        n = recv(sockfd, buffer, DEFAULT_BUFLEN, 0);
        if (n <= 0) {
            printf("接收中断\n");
            break;
        }
        fwrite(buffer, sizeof(char), n, fp);
        nowSize += n;
    }
    snprintf(buffer, DEFAULT_BUFLEN, "文件 %s 接收完成", fileName);
    convertEncoding("UTF-8", "GBK", buffer, buffer, DEFAULT_BUFLEN);
    send(sockfd, buffer, strlen(buffer), 0);
    fclose(fp);
}

bool endsWithBackslash(const char* str) {
	size_t length = strlen(str);
	if (length > 0 && (str[length - 1] == '\\'||str[length - 1] == '/')) {
		return true;
	}
	return false;
}

bool folderExists(const char* folderPath) {
    struct stat info;
    if (stat(folderPath, &info) != 0) {
        return false;
    }
    return S_ISDIR(info.st_mode);
}

void RemoveLastFolder(char* path) {
    size_t len = strlen(path);

    if (len == 0)
        return;

    size_t i = len - 1;
    while (i > 0 && (path[i] == '/' || path[i] == '\\'))
        i--;

    while (i > 0 && path[i] != '/' && path[i] != '\\')
        i--;

    if (i > 0)
        path[i + 1] = '\0';
}

int main() {
    int sockfd, newsockfd;
    struct sockaddr_in addr, cli_addr;
    socklen_t clilen;

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        error("Failed to create socket");
    }

    memset(&addr, 0, sizeof(addr));
    addr.sin_family = AF_INET;
    addr.sin_port = htons(0);
    addr.sin_addr.s_addr = INADDR_ANY;

    if (bind(sockfd, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
        error("Bind failed");
    }

    clilen = sizeof(cli_addr);
    if (getsockname(sockfd, (struct sockaddr*)&addr, &clilen) < 0) {
        error("Error getting socket address");
    }

    if (listen(sockfd, 5) < 0) {
        error("Listen failed");
    }
	
	char ip[INET_ADDRSTRLEN];
    if (getLocalIP(ip) != 0) {
        printf("无法获取本机的局域网IP地址\n");
    }

    // 显示设备的 IP 地址和动态分配的端口号
    printf("接收端已启动\n");
    printf("IP 地址: %s\n", ip);
    printf("端口号: %hu\n", ntohs(addr.sin_port));

    char parentPath[FILENAME_MAX];
    getcwd(parentPath, sizeof(parentPath));
    strcat(parentPath, "/");
    char finishStr[] = "创建文件夹成功";
    char finishStr2[] = "返回上一级目录成功";
    char buffer[DEFAULT_BUFLEN];
    while (1)
    {
        char nowPath[FILENAME_MAX];
        strcpy(nowPath, parentPath);
        chdir(nowPath);

        printf("等待发送端连接...\n");
        newsockfd = accept(sockfd, (struct sockaddr*)&cli_addr, &clilen);
        if (newsockfd < 0) {
            error("连接发送端失败");
        }
        printf("发送端连接成功\n");

        while (1) {
            int n = recv(newsockfd, buffer, DEFAULT_BUFLEN, 0);
            if (n <= 0) {
                break;
            }
            buffer[n] = '\0';
            convertEncoding("GBK", "UTF-8", buffer, buffer, DEFAULT_BUFLEN);

            if (strcmp(buffer, "end") == 0) {
                break;
            }

            if (strcmp(buffer, "..") == 0) {
                RemoveLastFolder(nowPath);
                chdir(nowPath);
                convertEncoding("UTF-8", "GBK", finishStr2, buffer, DEFAULT_BUFLEN);
                send(newsockfd, buffer, strlen(buffer), 0);
                continue;
            }

            char combinePath[FILENAME_MAX];
            snprintf(combinePath, FILENAME_MAX, "%s%s", nowPath, buffer);
            replaceBackslashWithSlash(combinePath);
            if (endsWithBackslash(combinePath)) {
                strcpy(nowPath, combinePath);
                if (!folderExists(nowPath)) {
                    if (mkdir(nowPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH) < 0) {
                        printf("创建文件夹%s失败\n", nowPath);
                    }
                    else {
                        printf("创建文件夹%s成功\n", nowPath);
                    }
                }

                if (chdir(nowPath) < 0) {
                    printf("进入文件夹%s失败\n", nowPath);
                }
                printf("进入文件夹%s成功\n", nowPath);
                convertEncoding("UTF-8", "GBK", finishStr, buffer, DEFAULT_BUFLEN);
                send(newsockfd, buffer, strlen(buffer), 0);
            }
            else {
                printf("开始接收文件%s\n", buffer);
                receiveFile(newsockfd, combinePath);
            }
        }
        
        char answer;
        printf("接收完成是否继续接收文件？(y/n): ");
        scanf(" %c", &answer);
        if (answer != 'y' && answer != 'Y') {
            break;
        }
    }
    

    close(newsockfd);
    close(sockfd);

    return 0;
}

